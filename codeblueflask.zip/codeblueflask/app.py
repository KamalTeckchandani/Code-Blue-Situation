from flask import Flask, render_template, url_for
app = Flask(__name__)

@app.route("/index.html")
def index():
    return render_template('index.html')

@app.route("/property-grid.html")
def propertygrid():
    return render_template('property-grid.html')

@app.route("/medicines.html")
def medicines():
    return render_template('medicines.html')

@app.route("/graphs/plot1.html")
def plot1():
    return render_template('graphs/plot1.html')

@app.route("/graphs/plot2.html")
def plot2():
    return render_template('graphs/plot2.html')

@app.route("/graphs/plot3.html")
def plot3():
    return render_template('graphs/plot3.html')

@app.route("/graphs/plot4.html")
def plot4():
    return render_template('graphs/plot4.html')

@app.route("/graphs/plot5.html")
def plot5():
    return render_template('graphs/plot5.html')

@app.route("/graphs/plot6.html")
def plot6():
    return render_template('graphs/plot6.html')

@app.route("/graphs/plot7.html")
def plot7():
    return render_template('graphs/plot7.html')

@app.route("/graphs/plot8.html")
def plot8():
    return render_template('graphs/plot8.html')

@app.route("/graphs/plot9.html")
def plot9():
    return render_template('graphs/plot9.html')

@app.route("/graphs/plot10.html")
def plot10():
    return render_template('graphs/plot10.html')

@app.route("/graphs/plot11.html")
def plot11():
    return render_template('graphs/plot11.html')

@app.route("/graphs/plot12.html")
def plot12():
    return render_template('graphs/plot12.html')

@app.route("/graphs/plot13.html")
def plot13():
    return render_template('graphs/plot13.html')

